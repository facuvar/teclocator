<?php
/**
 * Main entry point - redirects to login page
 */
header('Location: login.php');
exit;
