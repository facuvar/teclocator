CREATE DATABASE IF NOT EXISTS elevator_repair_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
